package com.aviatorsim.app;

import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView multiplierText;
    private TextView poolText;
    private EditText stakeInput;
    private Button startBtn, cashBtn;
    private RecyclerView historyList;
    private HistoryAdapter adapter;
    private List<String> history = new ArrayList<>();

    private Handler handler = new Handler();
    private Runnable ticker;
    private double multiplier = 1.0;
    private double crashPoint = 1.5;
    private boolean running = false;
    private int lastStake = 0;

    // Rigging variables (mirror python logic)
    private long totalCollected = 0;
    private final long FAKE_WIN_THRESHOLD = 100000; // when reached -> big win
    private final double SMALL_MIN = 1.01;
    private final double SMALL_MAX = 2.0;
    private final double BIG_MIN = 50.0;
    private final double BIG_MAX = 200.0;

    private Random rng = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        multiplierText = findViewById(R.id.multiplierText);
        poolText = findViewById(R.id.poolText);
        stakeInput = findViewById(R.id.stakeInput);
        stakeInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        startBtn = findViewById(R.id.startBtn);
        cashBtn = findViewById(R.id.cashBtn);
        historyList = findViewById(R.id.historyList);

        adapter = new HistoryAdapter(history);
        historyList.setLayoutManager(new LinearLayoutManager(this));
        historyList.setAdapter(adapter);

        updateUI();

        startBtn.setOnClickListener(v -> startRound());
        cashBtn.setOnClickListener(v -> cashOut());
    }

    private void startRound() {
        if (running) return;
        String s = stakeInput.getText().toString().trim();
        if (s.isEmpty()) {
            Toast.makeText(this, "Enter stake", Toast.LENGTH_SHORT).show();
            return;
        }
        int stake = Integer.parseInt(s);
        if (stake <= 0) {
            Toast.makeText(this, "Stake must be positive", Toast.LENGTH_SHORT).show();
            return;
        }
        lastStake = stake;
        // determine crash point based on rigging logic
        long updatedTotal = totalCollected + stake;
        if (updatedTotal < FAKE_WIN_THRESHOLD) {
            crashPoint = randomBetween(SMALL_MIN, SMALL_MAX);
        } else {
            crashPoint = randomBetween(BIG_MIN, BIG_MAX);
        }
        totalCollected = updatedTotal;

        running = true;
        multiplier = 1.0;
        updateUI();

        // start ticker: multiplier grows nonlinearly
        ticker = new Runnable() {
            @Override
            public void run() {
                if (!running) return;
                // growth: faster as multiplier rises
                multiplier += Math.max(0.01, multiplier * 0.01);
                multiplier = Math.round(multiplier * 100.0) / 100.0;
                if (multiplier >= crashPoint) {
                    // crash happens
                    running = false;
                    handleCrash();
                    updateUI();
                    return;
                }
                updateUI();
                handler.postDelayed(this, 80);
            }
        };
        handler.postDelayed(ticker, 80);
    }

    private void cashOut() {
        if (!running) return;
        running = false;
        double payout = lastStake * multiplier;
        String entry = String.format(Locale.getDefault(), "CASHOUT - Stake %d - Mult %.2fx - Payout %.2f", lastStake, multiplier, payout);
        history.add(0, entry);
        adapter.notifyDataSetChanged();
        // Note: pool stays as-is; only reset on big win per rigging logic when crash occurs
        Toast.makeText(this, "Cashed out: " + String.format(Locale.getDefault(), "%.2f", payout), Toast.LENGTH_SHORT).show();
        updateUI();
    }

    private void handleCrash() {
        double crashedAt = crashPoint;
        String entry;
        if (crashedAt >= BIG_MIN) {
            // big win triggered -> reset pool to 0
            entry = String.format(Locale.getDefault(), "BIG WIN! Crash at %.2fx — Stake %d was in play", crashedAt, lastStake);
            totalCollected = 0;
        } else {
            entry = String.format(Locale.getDefault(), "CRASH at %.2fx — Stake %d lost", crashedAt, lastStake);
        }
        history.add(0, entry);
        adapter.notifyDataSetChanged();
        updateUI();
    }

    private void updateUI() {
        multiplierText.setText(String.format(Locale.getDefault(), "%.2fx", multiplier));
        poolText.setText("Pool collected: Ksh " + totalCollected);
        startBtn.setEnabled(!running);
        cashBtn.setEnabled(running);
    }

    private double randomBetween(double min, double max) {
        return min + rng.nextDouble() * (max - min);
    }
}
